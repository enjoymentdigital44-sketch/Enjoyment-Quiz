# Top Level Challenge — Native Kotlin Android App

यो **Native Android + Kotlin + Jetpack Compose** प्रोजेक्ट हो; HTML/WebView एप होइन।

## APK बनाउने सबैभन्दा सजिलो तरिका (GitHub Actions)
1. GitHub मा नयाँ repository बनाउनुहोस्।
2. यस ZIP को सामग्री repository मा upload गर्नुहोस्।
3. `main` branch मा commit/push गर्नुहोस् वा GitHub → Actions → **Build Native Android APK** → **Run workflow** छान्नुहोस्।
4. Workflow सफल भएपछि `TopLevelChallenge-debug-apk` artifact डाउनलोड गर्नुहोस्।
5. ZIP artifact भित्र `app-debug.apk` हुन्छ; Android फोनमा खोल्दा install गर्न सकिन्छ (आवश्यक परे “Install unknown apps” अनुमति दिनुहोस्)।

## Android Studio बाट
यो folder Android Studio मा खोल्नुहोस्, Gradle sync हुन दिनुहोस्, अनि **Build → Build APK(s)** छान्नुहोस्।

Package: `com.enjoymentdigital.toplevelchallenge`
Version: `1.0`
