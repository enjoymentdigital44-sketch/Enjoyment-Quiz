package com.enjoymentdigital.toplevelchallenge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class QuizQuestion(
    val question: String,
    val answers: List<String>,
    val correct: Int,
    val level: Int
)

private val quiz = listOf(
    QuizQuestion("नेपालको राजधानी कुन हो?", listOf("पोखरा", "काठमाडौं", "बुटवल", "विराटनगर"), 1, 1),
    QuizQuestion("एक हप्तामा कति दिन हुन्छन्?", listOf("५", "६", "७", "८"), 2, 1),
    QuizQuestion("२ + ३ × २ कति हुन्छ?", listOf("१०", "१२", "८", "७"), 2, 1),
    QuizQuestion("सूर्य कुन दिशाबाट उदाउँछ?", listOf("पश्चिम", "उत्तर", "दक्षिण", "पूर्व"), 3, 2),
    QuizQuestion("नेपालको राष्ट्रिय फूल कुन हो?", listOf("गुलाब", "लालीगुराँस", "कमल", "सयपत्री"), 1, 2),
    QuizQuestion("३० को आधा र त्यसमा ५ जोड्दा कति हुन्छ?", listOf("१०", "१५", "२०", "२५"), 2, 2),
    QuizQuestion("कुन ग्रहलाई रातो ग्रह भनिन्छ?", listOf("शुक्र", "मंगल", "बृहस्पति", "शनि"), 1, 3),
    QuizQuestion("१ किलोमा कति ग्राम हुन्छ?", listOf("१००", "५००", "१०००", "१०,०००"), 2, 3),
    QuizQuestion("घडीमा ३ बज्दा दुई काँटाबीचको कोण कति हुन्छ?", listOf("४५°", "९०°", "१८०°", "३६०°"), 1, 3),
    QuizQuestion("नेपालको राष्ट्रिय जनावर कुन हो?", listOf("बाघ", "गाई", "हात्ती", "घोडा"), 1, 4),
    QuizQuestion("क्रम पूरा गर: २, ४, ८, १६, ?", listOf("१८", "२४", "३०", "३२"), 3, 4),
    QuizQuestion("कुन महिनामा २८ दिन हुन्छ?", listOf("फेब्रुअरी मात्र", "जुन", "सबै महिनामा", "अप्रिल"), 2, 4),
    QuizQuestion("तिमीसँग ३ वटा स्याउ छन्, २ वटा उठायौ। तिमीसँग कति स्याउ छन्?", listOf("१", "२", "३", "५"), 1, 5),
    QuizQuestion("दौडमा दोस्रो स्थानको व्यक्तिलाई उछिन्यौ भने कुन स्थानमा हुन्छौ?", listOf("पहिलो", "दोस्रो", "तेस्रो", "चौथो"), 1, 5),
    QuizQuestion("डिजिटल अंकमा उल्टो लेख्दा पनि उस्तै देखिने संख्या कुन हो?", listOf("२", "६", "८", "९"), 2, 5)
)

private val deepNavy = Color(0xFF100E2B)
private val purple = Color(0xFF8B5CF6)
private val pink = Color(0xFFD946EF)
private val pale = Color(0xFFF8F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GameApp() }
    }
}

@Composable
private fun GameApp() {
    var started by remember { mutableStateOf(false) }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var correctCount by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var finished by remember { mutableStateOf(false) }
    val questions = remember { quiz.shuffled() }
    val current = questions[index.coerceIn(0, questions.lastIndex)]

    MaterialTheme(colorScheme = darkColorScheme(
        primary = purple,
        secondary = pink,
        background = deepNavy,
        surface = Color(0xFF211D4A),
        onPrimary = Color.White,
        onBackground = pale,
        onSurface = pale
    )) {
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF35256C), deepNavy))
            ).padding(18.dp),
            contentAlignment = Alignment.Center
        ) {
            if (!started) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🧠", fontSize = 64.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("TOP LEVEL", fontSize = 17.sp, fontWeight = FontWeight.Black, color = Color(0xFFF0ABFC))
                    Text("CHALLENGE", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = pale, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(10.dp))
                    Text("दिमाग छ भने लेभल पार गर!", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = pale)
                    Spacer(Modifier.height(8.dp))
                    Text("५ लेभल • १५ प्रश्न • पोइन्ट र च्यालेन्ज", color = Color(0xFFC8C4E8), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(28.dp))
                    Button(onClick = { started = true }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                        Text("गेम सुरु गरौँ 🚀", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else if (finished) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (correctCount >= 12) "🏆" else "🎮", fontSize = 64.sp)
                    Text(if (correctCount >= 12) "वाह! च्याम्पियन!" else "राम्रो प्रयास!", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = pale)
                    Spacer(Modifier.height(12.dp))
                    Text("तिम्रो स्कोर: $score", fontSize = 23.sp, color = Color(0xFFF0ABFC), fontWeight = FontWeight.Bold)
                    Text("सही उत्तर: $correctCount / ${questions.size}", color = Color(0xFFC8C4E8))
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = {
                        index = 0; score = 0; correctCount = 0; selected = -1; finished = false
                    }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                        Text("फेरि खेल्ने 🔁")
                    }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Color(0xFF211D4A).copy(alpha = 0.94f), RoundedCornerShape(24.dp))
                        .padding(20.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("लेभल ${current.level}", color = Color(0xFFF0ABFC), fontWeight = FontWeight.Bold)
                        Text("⭐ $score", color = pale, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { (index + 1).toFloat() / questions.size },
                        modifier = Modifier.fillMaxWidth(),
                        color = pink,
                        trackColor = Color.White.copy(alpha = 0.15f)
                    )
                    Spacer(Modifier.height(18.dp))
                    Text("प्रश्न ${index + 1}/${questions.size}", color = Color(0xFFC8C4E8), fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(current.question, color = pale, fontSize = 22.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
                    Spacer(Modifier.height(18.dp))
                    current.answers.forEachIndexed { i, answer ->
                        val isCorrect = selected != -1 && i == current.correct
                        val isWrongSelected = selected == i && i != current.correct
                        val container = when {
                            isCorrect -> Color(0xFF17664E)
                            isWrongSelected -> Color(0xFF7F2945)
                            else -> Color.White.copy(alpha = 0.08f)
                        }
                        Button(
                            onClick = {
                                if (selected == -1) {
                                    selected = i
                                    if (i == current.correct) {
                                        score += 100
                                        correctCount++
                                    }
                                }
                            },
                            enabled = selected == -1,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = container,
                                disabledContainerColor = container,
                                contentColor = pale,
                                disabledContentColor = pale
                            )
                        ) {
                            Text("${'A' + i}. $answer", modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), fontSize = 16.sp)
                        }
                    }
                    if (selected != -1) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (selected == current.correct) "🎉 सही जवाफ! +100 पोइन्ट" else "🙂 सही उत्तर: ${current.answers[current.correct]}",
                            color = if (selected == current.correct) Color(0xFF6EE7B7) else Color(0xFFFDA4AF),
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                if (index == questions.lastIndex) finished = true
                                else { index++; selected = -1 }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                        ) {
                            Text(if (index == questions.lastIndex) "नतिजा हेर 🏆" else "अर्को प्रश्न ➜")
                        }
                    }
                }
            }
        }
    }
}
